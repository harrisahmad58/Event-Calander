#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Event.h"

Event::Event(string n)
{
    name = n;
}

void Event::setDate(int y, int m, int d, int h, int min)
{
    date.set(y, m, d, h, min);
}

Date& Event::getDate()
{
    return date;
}

void Event::print()
{
    cout << setfill(' ') << setw(20) << name << ": ";
    date.printLong();
}


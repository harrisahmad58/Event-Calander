//
// Created by Shahid on 2018-11-06.
//

#ifndef COMP_2404_A1_CONTROL_H
#define COMP_2404_A1_CONTROL_H

#include <adoctint.h>
#include "View.h"
#include "Calendar.h"

class Control{

public:
    void launch();
private:
    Calendar c;
    View view;
};

#endif //COMP_2404_A1_CONTROL_H

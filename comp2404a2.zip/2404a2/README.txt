Harris Ahmad
101055312

the purpose of this code is to create a calendar to hold event names and there  dates also to output it accordingly

all the files included are:
view.cc
view.h
control.cc
control.h
Calendar.cc
Calendar.h
Date.cc
Date.h
Event.cc
Event.h
in.txt
main.cc
Makefile
Time.cc
Time.h

to compile this program simply go in the terminal in a directory with all the
files and type: make

once the program launches just follow instructions on the terminal screen

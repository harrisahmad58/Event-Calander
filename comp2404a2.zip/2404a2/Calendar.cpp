//
// Created by Shahid on 2018-10-09.
//
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Calendar.h"

Calendar::Calendar(string cn) {
    CalendarName = cn;
}

Calendar::~Event() {
}

//Calendar::~Event() {}
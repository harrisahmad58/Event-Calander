#ifndef EVENT_H
#define EVENT_H

#include <string>
#include "Date.h"


class Event
{
public:
    Event(string="Default");
    void  setDate(int=0, int=0, int=0, int=0, int=0);
    Date& getDate();
    void  print();

private:
    string name;
    Date   date;
};

#endif


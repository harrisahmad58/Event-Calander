//
// Created by Shahid on 2018-11-06.
//

#ifndef COMP_2404_A1_VIEW_H
#define COMP_2404_A1_VIEW_H
#include "Calendar.h"

class View {

public:
    void mainMenu(int&);
    void printCalendar(Calendar&);
    void pause();

private:
    int readInt();
};

#endif //COMP_2404_A1_VIEW_H

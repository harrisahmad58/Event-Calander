//
// Created by Shahid on 2018-11-06.
//
#include <sstream>
#include <iomanip>
#include <iostream>
using namespace std;

#include "View.h"
#include "Calendar.h"


void View::mainMenu(int& choice) {
    string str;

    choice = -1;

    cout<< "\n\n\n         **** Event Calendar Info ****        \n\n";
    cout<< "                                 MAIN MENU          \n\n";
    cout<< "        1. Print Calendar                           \n\n";
    cout<< "        0. Exit                                     \n\n";

    while (choice < 0 || choice > 1) {
        cout << "Enter your selection:  ";
        choice = readInt();
    }

    if (choice == 0) { cout << endl; }
}


void View::printCalendar(Calendar & arr) {
    cout << endl << "CALENDAR : " << endl << endl;
}

void View::pause() {
    string str;

    cout << "Press enter to continue...";
    getline(cin, str);
}

int View::readInt() {
    string str;
    int    num;

    getline(cin, str);
    stringstream ss(str);
    ss >> num;

    return num;
}

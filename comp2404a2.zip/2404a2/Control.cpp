//
// Created by Shahid on 2018-11-06.
//

#include "Control.h"

void Control::launch() {

//    int ch;
//
//    while (1) {
//        ch = -1;
//        view.mainMenu(ch);
//
//        if (ch == 1) {
//            view.printCalendar();
//            view.pause();
//        }
//
//        else {
//            break;
//        }
//    }
}


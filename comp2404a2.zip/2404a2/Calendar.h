//
// Created by Shahid on 2018-10-09.
//

#ifndef COMP_2404_A1_CALENDAR_H
#define COMP_2404_A1_CALENDAR_H
#include "Date.h"
#include <string>
using namespace std;

class Calendar{
public:
    Calendar(string);
    ~Event();
    string CalendarName;
private:
};

#endif //COMP_2404_A1_CALENDAR_H

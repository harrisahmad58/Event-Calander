//
// Created by Shahid on 2018-02-25.
//

#include "VehicleArray.h"
//#include "Vehicle.h"
//#include "defs.h"

VehicleArray :: VehicleArray() : size(0){
    for(int i = 0 ; i < MAX_VEHICLES; i++){
        elements[i] = 0;
    }
}

int VehicleArray :: add(Vehicle * vehicle) {
    if(size >= MAX_VEHICLES){
        return C_NOK;
    }
    elements[size++] = vehicle;
}

Vehicle* VehicleArray :: get(int list) {
    if(list < 0 || list >= size){
        return 0;
    }
    return elements[list];
}

VehicleArray :: ~VehicleArray() {}

int VehicleArray :: getSize() { return size;}
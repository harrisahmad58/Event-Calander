//
// Created by Shahid on 2018-02-25.
//

#include "Vehicle.h"

Vehicle :: Vehicle(string make, string model, string colour, int year, int mileage) {
    this -> make = make;
    this -> model = model;
    this -> colour = colour;
    this -> year = year;
    this -> mileage = mileage;
}

string Vehicle :: getMake() { return  make;}
string Vehicle :: getModel() { return model;}
string Vehicle :: getColour() { return colour;}
int Vehicle :: getYear() { return year;}
int Vehicle :: getMilage() { return mileage;}
//
// Created by Shahid on 2018-02-25.
//
#include "ShopController.h"

ShopController::ShopController() {

    initCustomers();

}

void ShopController::launch() {

    int choice;

    while (1) {
        choice = -1;
        view.mainMenu(choice);

        if (choice == 1) {
            view.printCustomers(mechanicShop.getCustomers());
            view.pause();
        } /*else if (choice == 2) {

        } else if (choice == 3) {

        } else if (choice == 4) {

        } ... */

        else {
            break;
        }
    }
}


void ShopController::initCustomers() {
    Customer* c;
    Vehicle* v1;
    Vehicle* v2;
    Vehicle* v3;
    Vehicle* v4;

    c = new Customer("Maurice", "Maurice", "2600 Colonel By Dr.", "(613)728-9568");
    v1 = new Vehicle("Ford", "Fiesta", "Red", 2007, 100000);
    c -> addVehicle(v1);
    mechanicShop.addCustomer(c);

    c = new Customer("Abigail", "Abigail", "43 Carling Dr.", "(613)345-6743");
    v1 = new Vehicle("Subaru", "Forester", "Green", 2016, 40000);
    c -> addVehicle(v1);
    mechanicShop.addCustomer(c);

    c = new Customer("Brook", "Brook", "1 Bayshore Dr.", "(613)123-7456");
    v1 = new Vehicle("Honda", "Accord", "White", 2018, 5000);
    v2 = new Vehicle("Volkswagon", "Beetle", "White", 1972, 5000);
    c -> addVehicle(v1);
    c -> addVehicle(v2);
    mechanicShop.addCustomer(c);

    c = new Customer("Ethan", "Ethan", "245 Rideau St.", "(613)234-9677");
    v1 = new Vehicle("Toyota", "Camery", "Black", 2010, 50000);
    c -> addVehicle(v1);
    mechanicShop.addCustomer(c);

    c = new Customer("Eve", "Eve", "75 Bronson Ave.", "(613)456-2345");
    v1 = new Vehicle("Toyota", "Corolla", "Green", 2013, 80000);
    v2 = new Vehicle("Toyota", "Rav4", "Gold", 2015, 20000);
    v3 = new Vehicle("Toyota", "Prius", "Blue", 2017, 10000);
    c -> addVehicle(v1);
    c -> addVehicle(v2);
    c -> addVehicle(v3);
    mechanicShop.addCustomer(c);

    c = new Customer("Victor", "Victor", "425 O'Connor St.", "(613)432-7622");
    v1 = new Vehicle("GM", "Envoy", "Purple", 2012, 60000);
    v2 = new Vehicle("GM", "Escalade", "Black", 2016, 40000);
    v3 = new Vehicle("GM", "Malibu", "Red", 2015, 20000);
    v4 = new Vehicle("GM", "Trailblazer", "Orange", 2012, 90000);
    c -> addVehicle(v1);
    c -> addVehicle(v2);
    c -> addVehicle(v3);
    c -> addVehicle(v4);
    mechanicShop.addCustomer(c);
}

//add data fill here

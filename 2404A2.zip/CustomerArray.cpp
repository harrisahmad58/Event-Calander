//
// Created by Shahid on 2018-02-25.
//
#include "CustomerArray.h"
//#include "Customer.h"
//#include "defs.h"

CustomerArray :: CustomerArray() : size(0){
    for(int i = 0 ; i < MAX_CUSTOMERS; i++){
        elements[i] = 0;
    }
}

int CustomerArray :: add(Customer * customer) {
    if(size >= MAX_CUSTOMERS){
        return C_NOK;
    }
    elements[size++] = customer;


    return C_OK;
}

Customer* CustomerArray :: get(int list) {
    if(list < 0 || list >= size){
        return 0;
    }
    return elements[list];
}

CustomerArray :: ~CustomerArray() {
}

int CustomerArray :: getSize() { return size;}

//
// Created by Shahid on 2018-02-25.
//
#include <iostream>
using namespace std;
#include "Customer.h"

int Customer :: nextId = 1000;

Customer ::Customer(string fname, string lname, string address, string phonenum) {
    this -> firstName = fname;
    this -> lastName = lname;
    this -> address = address;
    this -> phoneNumber = phonenum;
}

int Customer :: getId() { return id;}
string Customer :: getFname() { return firstName;}
string Customer :: getLname() { return lastName;}
string Customer :: getAddress() { return address;}
string Customer :: getPhoneNumber() { return phoneNumber;}
int Customer :: getNumVehicles() {return vehicles.getSize();}
VehicleArray& Customer :: getVehicles() { return vehicles;}

int Customer :: addVehicle(Vehicle * Vehicle) {
    if(getNumVehicles() < MAX_VEHICLES){
        vehicles.add(Vehicle);
    }
    nextId++;
}
